package facadepattern;


public class SistemaDeInput {
	public void configurarTeclado() {
		System.out.println("Teclado configurado");
	}

	public void configurarJoystick() {
		System.out.println("Joystick configurado");
	}

	public void lerInput() {
		System.out.println("Botão # pressionada");
	}
}
