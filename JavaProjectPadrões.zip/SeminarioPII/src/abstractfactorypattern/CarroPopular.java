package abstractfactorypattern;

public interface CarroPopular {
	void exibirInfoPopular();
}
