package abstractfactorypattern;

public interface CarroSedan {
	void exibirInfoSedan();
}
